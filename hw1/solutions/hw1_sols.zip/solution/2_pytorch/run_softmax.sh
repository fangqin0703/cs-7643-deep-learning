#!/bin/sh
#############################################################################
# TODO: Modify the hyperparameters such as hidden layer dimensionality, 
#       number of epochs, weigh decay factor, momentum, batch size, learning 
#       rate mentioned here to achieve good performance
#############################################################################
python -u train.py \
    --model softmax \
    --epochs 2 \
    --weight-decay 150.0 \
    --momentum 0.3 \
    --batch-size 128 \
    --lr 0.00003 | tee softmax.log
#############################################################################
#                             END OF YOUR CODE                              #
#############################################################################
