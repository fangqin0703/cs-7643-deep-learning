#!/bin/sh
#############################################################################
# TODO: Modify the hyperparameters such as hidden layer dimensionality, 
#       number of epochs, weigh decay factor, momentum, batch size, learning 
#       rate mentioned here to achieve good performance
#############################################################################
python -u train.py \
    --model twolayernn \
    --hidden-dim 50 \
    --epochs 5 \
    --weight-decay 1.0 \
    --momentum 0.9 \
    --batch-size 64 \
    --lr 0.00001 | tee twolayernn.log
#############################################################################
#                             END OF YOUR CODE                              #
#############################################################################
