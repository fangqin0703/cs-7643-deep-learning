# EvalAI Challenge

The CNN architecture is as follows:
conv -> relu -> pool -> affine -> softmax

Filter size is 3 and the number of filters is 32. SGD with momentum and L2 regularization is used.


# Submission details

Username: niranjantdesai
Team name: Grad Student Descent